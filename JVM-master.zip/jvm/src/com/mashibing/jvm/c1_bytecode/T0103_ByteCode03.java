package com.mashibing.jvm.c1_bytecode;

public class T0103_ByteCode03 {
    int i = 0;
    String s = "Hello ByteCode!";
}

package com.mashibing.jvm.c1_bytecode;

public class T0104_ByteCode05 {
    int i = 0;
    String s = "Hello ByteCode!";

    public T0104_ByteCode05(int i, String s) {
        this.i = i;
        this.s = s;
    }

    public void m() {}
}

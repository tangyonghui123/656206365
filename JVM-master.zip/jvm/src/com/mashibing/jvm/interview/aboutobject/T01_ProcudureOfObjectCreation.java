package com.mashibing.jvm.interview.aboutobject;

public class T01_ProcudureOfObjectCreation {
    public static void main(String[] args) {
        T t = new T();
    }

    static class T{
        int m = 8;
    }
}

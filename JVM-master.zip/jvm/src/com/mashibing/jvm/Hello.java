package com.mashibing.jvm;

public class Hello {
    public void m() {
        System.out.println("Hello JVM!");
    }
}

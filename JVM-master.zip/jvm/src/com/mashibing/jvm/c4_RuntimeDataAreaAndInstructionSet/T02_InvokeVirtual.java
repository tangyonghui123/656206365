package com.mashibing.jvm.c4_RuntimeDataAreaAndInstructionSet;

public class T02_InvokeVirtual {
    public static void main(String[] args) {
        new T02_InvokeVirtual().m();
    }

    public void m() {}
}
